package com.example.shaygavbryan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    public CardView bryan,Shay;


    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        Shay = findViewById ( R.id.Shay);
        bryan = findViewById ( R.id.bryan );
        Shay.setOnClickListener (this);
        bryan.setOnClickListener ( this );
    }


    public void logout ( View view ) {
        FirebaseAuth.getInstance ().signOut ();//logout
        startActivity ( new Intent ( getApplicationContext () , ActivityLogin.class ) );
        finish ();
    }


    @Override
    public void onClick ( View v ) {
        Intent i;
        CardView shay;
        switch (v.getId ()) {
            case R.id.Shay:
                i = new Intent ( this ,Shay.class );
                startActivity ( i );
                break;
            case R.id.bryan:
                i = new Intent ( this , bryan.class );
                startActivity ( i );
                break;
            default:
                break;
        }

    }

}




