package com.example.shaygavbryan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class bryan extends AppCompatActivity {

    @Override
    protected void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_bryan );
    }
}
